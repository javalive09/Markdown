#!/usr/bin/env python

import os, string, sys, time, re, math, fileinput, glob, shutil, codecs
import threading, platform


VERSION = (0, 1)



#--------------------------------------------------------------------------------------------------
def get_project_dir() :	
	ret = "/home/alex/w/a/z_project/X70/"
	return ret

#--------------------------------------------------------------------------------------------------

def copy_files(src_dir, dst_dir, file_list):	
	print("src: " + src_dir)
	print("dst: " + dst_dir)
	print("list: " + file_list)
	if os.access(file_list, os.R_OK) == 0:
		print("no list file:"+ file_list  + "\n")
		return
	fp = codecs.open(file_list, 'r', 'utf-8', errors='ignore')
	lines = fp.readlines()
	fp.close()

	for line in lines:
		line = line.rstrip()
		print("try copy:"+ line  + "\n")
		if os.access(dst_dir + line, os.R_OK) == 1:
			print("file is exit:"+ line  + "\n")
			continue
		
		dir_for_this_file = os.path.dirname(dst_dir + line)
		if os.access(dir_for_this_file, os.R_OK) == 0:			
			print("make dirs:"+ dir_for_this_file  + "\n")
			os.makedirs(dir_for_this_file)
		
		print("copy file:"+ line  + "\n")
		shutil.copy(src_dir + line, dst_dir + line)
	return


#--------------------------------------------------------------------------------------------------
def main(argv):
        root_dir = get_project_dir() 
	in_dir = root_dir + "/android/"	
	out_dir = root_dir + "/wutong/aosp/"
	
	file_list = root_dir + "/all_copy_list.txt"
			
	copy_files(in_dir, out_dir, file_list)

	

	return

if __name__ == '__main__':
	main(sys.argv)


