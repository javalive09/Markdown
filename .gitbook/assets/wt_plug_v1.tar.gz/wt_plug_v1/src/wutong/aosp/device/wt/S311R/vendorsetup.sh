add_lunch_combo S311R-eng
add_lunch_combo S311R-user
add_lunch_combo S311R-userdebug
